import os, re, requests, random
from pathlib import Path
import edge_tts
import asyncio
from moviepy.editor import VideoFileClip, AudioFileClip, CompositeVideoClip, TextClip, concatenate_videoclips
from moviepy.video.fx.resize import resize

PEXELS_URL = "https://api.pexels.com/videos/search"

def search_pexels(api_key, query, per_page=5):
    if not api_key or "PUT" in api_key:
        return []
    headers = {"Authorization": api_key}
    # ترجمة بسيطة للبحث عشان Pexels انجليزي
    q = query
    mapping = {"شقة": "apartment night", "بوليس": "police crime scene", "ليل": "night city", "دليل": "detective evidence", "مباحث": "detective"}
    for k,v in mapping.items():
        if k in query:
            q = v
            break
    if any(ord(c) > 127 for c in query):
        q = "crime scene night"
    r = requests.get(PEXELS_URL, headers=headers, params={"query": q, "per_page": per_page, "orientation": "portrait"})
    if r.status_code != 200:
        return []
    vids = r.json().get("videos", [])
    urls = []
    for v in vids:
        # اختار جودة متوسطة
        files = v.get("video_files", [])
        if files:
            # portrait
            best = sorted(files, key=lambda x: x.get("width",0))[-1]
            urls.append(best["link"])
    return urls

async def text_to_speech(text, voice, out_path):
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(out_path)

def build_audio(script_text, voice, out_path):
    # نظف السكريبت وخد النص فقط
    clean = re.sub(r"مشهد \d+:.*\n", "", script_text)
    clean = re.sub(r"\[.*?\]", "", clean)
    clean = clean.replace("نص:", "").strip()
    # خد اول 800 حرف عشان TTS
    clean = clean[:1000]
    asyncio.run(text_to_speech(clean, voice, out_path))
    return out_path, clean

def build_video(video_urls, audio_path, output_path, width=1080, height=1920):
    if not video_urls:
        # لو مفيش pexels، اعمل فيديو اسود بصوت فقط
        from moviepy.editor import ColorClip
        audio = AudioFileClip(audio_path)
        clip = ColorClip(size=(width, height), color=(15,15,15), duration=audio.duration)
        clip = clip.set_audio(audio)
        clip.write_videofile(output_path, fps=24, codec="libx264", audio_codec="aac")
        return output_path

    clips = []
    # حمل الفيديوهات
    tmp_dir = Path("storage/tmp")
    tmp_dir.mkdir(parents=True, exist_ok=True)
    for i, url in enumerate(video_urls[:3]):
        try:
            local = tmp_dir / f"clip_{i}.mp4"
            with requests.get(url, stream=True, timeout=20) as r:
                with open(local, 'wb') as f:
                    for chunk in r.iter_content(1024*512):
                        f.write(chunk)
            vc = VideoFileClip(str(local)).subclip(0, 3)
            vc = vc.resize((width, height))
            clips.append(vc)
        except Exception as e:
            print("clip fail", e)
            continue

    if not clips:
        from moviepy.editor import ColorClip
        audio = AudioFileClip(audio_path)
        clip = ColorClip(size=(width, height), color=(15,15,15), duration=audio.duration)
        clip = clip.set_audio(audio)
        clip.write_videofile(output_path, fps=24, codec="libx264", audio_codec="aac")
        return output_path

    final_video = concatenate_videoclips(clips, method="compose")
    audio = AudioFileClip(audio_path)
    # لو الفيديو اقصر من الصوت، اعمله loop
    if final_video.duration < audio.duration:
        final_video = final_video.loop(duration=audio.duration)

    final_video = final_video.subclip(0, audio.duration).set_audio(audio)
    final_video.write_videofile(output_path, fps=24, codec="libx264", audio_codec="aac")
    return output_path