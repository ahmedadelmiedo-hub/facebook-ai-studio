import os
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

PROMPT_TEMPLATE = """
أنت المؤلف الرئيسي لمسلسل إذاعي/مرئي جرائم واقعية اسمه "{series_name}" - "المحقق الذكي"

المطلوب: اكتب الحلقة رقم {episode_num} بعنوان: "{episode_title}"

{context}

موضوع الجريمة الخاص بالحلقة دي: {subject}

قواعد ذهبية لا تكسرها:
1. لازم تربط الحلقة بدليل من لوحة الأدلة
2. الحوار يكون واقعي ومصري عامي خفيف ممزوج بفصحى للراوي
3. كل حلقة 5-6 مشاهد، كل مشهد: [وصف بصري للمونتاج] + نص الراوي
4. اكتب بصيغة:
   مشهد 1: [وصف: شقة ضلمة، فلاش كاميرا...]
   نص: "..."
5. في الآخر لازم تكتب 3 أسطر منفصلة:
   ملخص: ...
   دليل جديد: ...
   CLIFFHANGER: ...

مدة النص لا تزيد عن 400 كلمة ليكون فيديو 60-90 ثانية.
"""

def write_episode(series_name, episode_num, episode_title, subject, context, api_key=None, base_url=None, model=None):
    # لو مفيش مفتاح، رجع سكريبت تجريبي عشان المشروع يشتغل حتى بدون LLM
    if not api_key:
        demo_script = f"""
مشهد 1: [لقطة جوية لطنطا بالليل، عربية بوليس]
نص: أنا المقدم ياسر العطار، ودي مش أول مرة أدخل شقة مقفولة من جوه وجثة مرمية على الأرض.

مشهد 2: [فلاش على الحيطة مكتوب عليها 71f28a بالدم]
نص: الرقم ده شفته قبل كده... في ملف مقفول من 2019. أمينة قالتلي ده مش دم الضحية.

مشهد 3: [أمينة بتصور الأدلة باللاب توب]
نص: أمينة لقت حاجة غريبة، بصمة محروقة على مقبض الباب، كأن حد حاول يمسحها بالنار.

مشهد 4: [ياسر بيبص في النوتة]
نص: الجريمة مبتكذبش، بس اللي عملها كان عارف احنا بندور على ايه.

مشهد 5: [جرس باب يرن فجأة]
نص: وقبل ما نخرج، الباب خبط... حد كان لسه في العمارة.

ملخص: اكتشاف رقم غامض وبصمة محروقة في شقة طنطا
دليل جديد: بصمة محروقة على المقبض + رقم 71f28a ليس دم الضحية
CLIFFHANGER: مين اللي خبط على الباب بعد ما البوليس قفل العمارة كلها؟
"""
        return demo_script, "اكتشاف رقم غامض وبصمة محروقة", "بصمة محروقة + رقم 71f28a", "مين اللي خبط على الباب؟"

    client = OpenAI(api_key=api_key, base_url=base_url if base_url else None)
    prompt = PROMPT_TEMPLATE.format(
        series_name=series_name,
        episode_num=episode_num,
        episode_title=episode_title,
        context=context,
        subject=subject
    )
    resp = client.chat.completions.create(
        model=model or "llama-3.3-70b-versatile",
        messages=[
            {"role": "system", "content": "أنت كاتب سيناريو جرائم محترف، تكتب بالعربي، مشوق، واقعي، مترابط."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.85
    )
    text = resp.choices[0].message.content

    # parsing بسيط
    summary = "ملخص الحلقة"
    evidence = "دليل جديد"
    cliff = "نهاية مشوقة"
    try:
        for line in text.split("\n"):
            if line.strip().startswith("ملخص:"):
                summary = line.replace("ملخص:","").strip()
            if line.strip().startswith("دليل جديد:"):
                evidence = line.replace("دليل جديد:","").strip()
            if "CLIFFHANGER:" in line:
                cliff = line.split("CLIFFHANGER:")[-1].strip()
    except:
        pass

    return text, summary, evidence, cliff