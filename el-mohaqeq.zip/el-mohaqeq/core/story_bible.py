import json, os
from datetime import datetime

MEMORY_FILE = "storage/series_memory.json"

class StoryBible:
    def __init__(self, series_name="الملف 71"):
        self.series_name = series_name
        os.makedirs("storage", exist_ok=True)
        if not os.path.exists(MEMORY_FILE):
            with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
                json.dump({}, f, ensure_ascii=False)

    def load_all(self):
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)

    def get_series(self):
        all_data = self.load_all()
        return all_data.get(self.series_name, {
            "series_name": self.series_name,
            "genre": "جرائم ومباحث واقعية",
            "characters": {
                "المقدم ياسر العطار": "42 سنة، محقق جنائي هادي، بيكتب ملاحظاته في نوتة صغيرة، لازمة: 'الجريمة مبتكذبش'",
                "أمينة - خبيرة الأدلة": "28 سنة، ذكية، بتقرأ مسرح الجريمة من التفاصيل الصغيرة، لاب توبها دايما معاها",
                "الراوي": "صوت ياسر نفسه بيحكي القصة"
            },
            "episodes": [],
            "evidence_board": [],
            "last_cliffhanger": "البداية",
            "created_at": datetime.now().isoformat()
        })

    def save_episode(self, episode_num, title, summary, new_evidence, cliffhanger, full_script):
        all_data = self.load_all()
        series = self.get_series()

        series["episodes"].append({
            "episode": episode_num,
            "title": title,
            "summary": summary,
            "script": full_script,
            "date": datetime.now().isoformat()
        })
        if new_evidence:
            series["evidence_board"].append({
                "episode": episode_num,
                "evidence": new_evidence
            })
        series["last_cliffhanger"] = cliffhanger

        all_data[self.series_name] = series
        with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(all_data, f, ensure_ascii=False, indent=2)
        return series

    def get_prompt_context(self):
        s = self.get_series()
        if not s["episodes"]:
            return "هذه هي الحلقة الأولى. عرّف الشخصيات: المقدم ياسر وأمينة، وابدأ بجريمة غامضة في شقة بطنطا ورقم 71f28a مكتوب على الحيطة."

        chars = "\n".join([f"- {k}: {v}" for k,v in s["characters"].items()])
        last_eps = "\n".join([f"ح{ep['episode']}: {ep['title']} - {ep['summary']}" for ep in s["episodes"][-3:]])
        evid = "\n".join([f"دليل ح{ev['episode']}: {ev['evidence']}" for ev in s["evidence_board"][-5:]])

        return f"""
الشخصيات الثابتة (ممنوع تغييرها):
{chars}

آخر الحلقات:
{last_eps}

لوحة الأدلة حتى الآن:
{evid}

آخر مشهد وقفنا عنده (لازم تكمل من هنا بالظبط):
{ s['last_cliffhanger'] }
"""