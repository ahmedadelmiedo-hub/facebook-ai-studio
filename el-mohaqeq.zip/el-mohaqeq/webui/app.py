import streamlit as st
import os, sys
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from core.story_bible import StoryBible
from core.episode_writer import write_episode
from core.video_builder import search_pexels, build_audio, build_video
import toml

st.set_page_config(page_title="المحقق الذكي", page_icon="🕵️", layout="wide", initial_sidebar_state="expanded")

# تحميل الكونفيج
config_path = "config.toml"
if not os.path.exists(config_path):
    config_path = "config.example.toml"
cfg = toml.load(config_path) if os.path.exists(config_path) else {}

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap');
html, body, [class*="css"] {font-family: 'Cairo', sans-serif; direction: rtl;}
</style>
""", unsafe_allow_html=True)

st.title("🕵️ المحقق الذكي - El-Mohaqeq")
st.caption("نظام توليد مسلسلات جرائم مترابطة - مبني على MoneyPrinterTurbo")

with st.sidebar:
    st.header("⚙️ الإعدادات")
    series_name = st.text_input("اسم المسلسل", value="الملف 71")
    episode_num = st.number_input("رقم الحلقة", min_value=1, value=1, step=1)
    episode_title = st.text_input("عنوان الحلقة", value="جثة بدون اسم")
    pexels_key = st.text_input("Pexels API Key", value=cfg.get("app",{}).get("pexels_api_key",""), type="password")
    openai_key = st.text_input("Groq/OpenAI Key (اختياري)", value=cfg.get("app",{}).get("openai_api_key",""), type="password")
    base_url = st.text_input("Base URL", value=cfg.get("app",{}).get("openai_base_url","https://api.groq.com/openai/v1"))
    model = st.text_input("Model", value=cfg.get("app",{}).get("llm_model","llama-3.3-70b-versatile"))
    yasser_voice = st.selectbox("صوت ياسر", ["ar-EG-ShakirNeural", "ar-SA-HamedNeural"], index=0)
    st.divider()
    if st.button("🗑️ مسح ذاكرة المسلسل"):
        import json
        if os.path.exists("storage/series_memory.json"):
            with open("storage/series_memory.json","r",encoding="utf-8") as f:
                data=json.load(f)
            if series_name in data:
                del data[series_name]
                with open("storage/series_memory.json","w",encoding="utf-8") as f:
                    json.dump(data,f,ensure_ascii=False,indent=2)
                st.success("تم المسح")

# عرض الذاكرة
bible = StoryBible(series_name)
series_data = bible.get_series()

col1, col2 = st.columns([2,1])
with col2:
    st.subheader("📚 لوحة القضية")
    st.write(f"**عدد الحلقات:** {len(series_data['episodes'])}")
    st.write("**الشخصيات:**")
    for k,v in series_data["characters"].items():
        st.markdown(f"- **{k}**: {v}")
    if series_data["evidence_board"]:
        st.write("**الأدلة:**")
        for ev in series_data["evidence_board"]:
            st.info(f"ح{ev['episode']}: {ev['evidence']}")
    if series_data["last_cliffhanger"]:
        st.warning(f"آخر نهاية: {series_data['last_cliffhanger']}")

with col1:
    subject = st.text_area("موضوع الجريمة لهذه الحلقة (تفصيلة جديدة)", value="جثة في شقة طنطا ورقم غامض على الحيطة", height=100)
    if st.button("✍️ اكتب السيناريو المترابط", type="primary"):
        context = bible.get_prompt_context()
        with st.spinner("المحقق الذكي بيكتب..."):
            script, summary, evidence, cliff = write_episode(series_name, episode_num, episode_title, subject, context, api_key=openai_key or None, base_url=base_url, model=model)
        st.session_state["last_script"] = script
        st.session_state["last_summary"] = summary
        st.session_state["last_evidence"] = evidence
        st.session_state["last_cliff"] = cliff
        st.success("تمت كتابة الحلقة!")

    if "last_script" in st.session_state:
        st.subheader(f"📝 سيناريو ح{episode_num}: {episode_title}")
        st.text_area("السيناريو", st.session_state["last_script"], height=400)
        c1,c2,c3 = st.columns(3)
        c1.metric("ملخص", st.session_state["last_summary"])
        c2.metric("دليل جديد", st.session_state["last_evidence"])
        c3.metric("Cliffhanger", st.session_state["last_cliff"])

        if st.button("💾 احفظ الحلقة في الذاكرة"):
            bible.save_episode(episode_num, episode_title, st.session_state["last_summary"], st.session_state["last_evidence"], st.session_state["last_cliff"], st.session_state["last_script"])
            st.success("اتحفظت! الحلقة الجاية هتكمل من هنا تلقائي")
            st.balloons()

        st.divider()
        st.subheader("🎬 توليد الفيديو")
        if st.button("🎥 حوّل السيناريو لفيديو"):
            with st.spinner("بنولد الصوت والفيديو..."):
                audio_path = f"storage/series/{series_name}_ep{episode_num}.mp3"
                os.makedirs("storage/series", exist_ok=True)
                from core.video_builder import build_audio
                import asyncio
                # بناء الصوت
                clean_text = st.session_state["last_script"]
                # استخدم asyncio
                import edge_tts
                async def gen():
                    comm = edge_tts.Communicate(clean_text[:900], yasser_voice)
                    await comm.save(audio_path)
                asyncio.run(gen())

                # بحث فيديوهات
                from core.video_builder import search_pexels, build_video
                urls = search_pexels(pexels_key, subject, per_page=3)
                out_video = f"storage/series/{series_name}_ep{episode_num}.mp4"
                build_video(urls, audio_path, out_video)

                st.video(out_video)
                with open(out_video, "rb") as f:
                    st.download_button("⬇️ حمّل الحلقة", f, file_name=f"{series_name}_ep{episode_num}.mp4")
            st.success("الفيديو جاهز!")