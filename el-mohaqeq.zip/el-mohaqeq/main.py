from core.story_bible import StoryBible
from core.episode_writer import write_episode
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="المحقق الذكي - CLI")
    parser.add_argument("--series", default="الملف 71")
    parser.add_argument("--episode", type=int, default=1)
    parser.add_argument("--title", default="جثة بدون اسم")
    parser.add_argument("--subject", default="جثة في طنطا ورقم غامض")
    args = parser.parse_args()

    bible = StoryBible(args.series)
    context = bible.get_prompt_context()
    print("=== Context ===")
    print(context)
    script, summary, evidence, cliff = write_episode(args.series, args.episode, args.title, args.subject, context)
    print("\n=== SCRIPT ===")
    print(script)
    bible.save_episode(args.episode, args.title, summary, evidence, cliff, script)
    print("\n✅ تم الحفظ في الذاكرة")