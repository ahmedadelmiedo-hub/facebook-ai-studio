# المحقق الذكي 🕵️ - El-Mohaqeq

نسخة مطورة من MoneyPrinterTurbo مخصصة لمسلسلات جرائم ومباحث مترابطة.

## المميزات الجديدة:
- 🧠 ذاكرة مسلسل كاملة (شخصيات + أدلة + ملخص حلقات)
- 🔗 كل حلقة بتكمل اللي قبلها تلقائي
- 🎙️ صوت ثابت للمحقق ياسر
- 🎬 فيديو 9:16 جاهز للريلز والتيك توك
- 📚 لوحة أدلة Evidence Board

## التشغيل السريع في Codespace:
```bash
pip install -r requirements.txt
cp config.example.toml config.toml
streamlit run webui/app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
```

## التشغيل المحلي:
نفس الأوامر.

## كيف تبدأ مسلسل؟
1. افتح الواجهة
2. اسم المسلسل: الملف 71
3. حلقة 1: جثة بدون اسم
4. دوس اكتب السيناريو -> احفظ في الذاكرة -> حول لفيديو
5. الحلقة 2 هتكمل تلقائي من نهاية الحلقة 1

المطور: Ahmed Zanobya
مبني على: harry0703/MoneyPrinterTurbo
